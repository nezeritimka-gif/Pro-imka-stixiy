package ru.imka.stihii;

import com.mojang.brigadier.CommandDispatcher;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.server.command.CommandManager;
import net.minecraft.server.command.ServerCommandSource;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.text.Text;
import net.minecraft.util.Hand;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;

import java.util.EnumMap;
import java.util.EnumSet;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public class StihiiMod implements ModInitializer {
    public static final String MOD_ID = "stihii";
    public enum Element { EARTH, WATER, LAVA, AIR }
    public static final Map<Element, Item> STAFFS = new EnumMap<>(Element.class);
    private static final Map<UUID, Integer> AWAKENING = new HashMap<>();
    private static final Map<UUID, EnumSet<Element>> X2_READY = new HashMap<>();

    @Override public void onInitialize() {
        registerStaff(Element.EARTH, "earth_staff");
        registerStaff(Element.WATER, "water_staff");
        registerStaff(Element.LAVA, "lava_staff");
        registerStaff(Element.AIR, "air_staff");
        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) -> registerCommands(dispatcher));
    }

    private static void registerStaff(Element element, String id) {
        Item item = Registry.register(Registries.ITEM, Identifier.of(MOD_ID, id), new ElementalStaffItem(element, new Item.Settings().maxCount(1)));
        STAFFS.put(element, item);
    }

    private static void registerCommands(CommandDispatcher<ServerCommandSource> dispatcher) {
        dispatcher.register(CommandManager.literal("stihii")
            .then(CommandManager.literal("earth").executes(ctx -> give(ctx.getSource(), Element.EARTH)))
            .then(CommandManager.literal("water").executes(ctx -> give(ctx.getSource(), Element.WATER)))
            .then(CommandManager.literal("lava").executes(ctx -> give(ctx.getSource(), Element.LAVA)))
            .then(CommandManager.literal("air").executes(ctx -> give(ctx.getSource(), Element.AIR)))
        );
    }

    private static int give(ServerCommandSource source, Element element) throws com.mojang.brigadier.exceptions.CommandSyntaxException {
        ServerPlayerEntity player = source.getPlayerOrThrow();
        player.giveItemStack(new ItemStack(STAFFS.get(element)));
        return 1;
    }

    public static String elementName(Element e) {
        return switch (e) { case EARTH -> "Земли"; case WATER -> "Воды"; case LAVA -> "Лавы"; case AIR -> "Воздуха"; };
    }

    public static void activate(ServerPlayerEntity player, Element element) {
        UUID id = player.getUuid();
        int progress = AWAKENING.getOrDefault(id, 0) + 20;
        boolean x2 = X2_READY.getOrDefault(id, EnumSet.noneOf(Element.class)).contains(element);
        if (x2) {
            X2_READY.get(id).remove(element);
        }
        applyAbility(player, element, x2);
        if (progress >= 100) {
            AWAKENING.put(id, 0);
            X2_READY.put(id, EnumSet.allOf(Element.class));
            player.sendMessage(Text.literal("Пробуждение завершено! Каждая стихия получила одно усиленное применение ×2."), true);
        } else {
            AWAKENING.put(id, progress);
        }
    }

    private static void applyAbility(ServerPlayerEntity player, Element element, boolean x2) {
        ServerWorld world = player.getServerWorld();
        int radius = x2 ? 20 : 10;
        switch (element) {
            case AIR -> {
                var abilities = player.getAbilities();
                abilities.allowFlying = true;
                abilities.flying = true;
                abilities.setFlySpeed(0.08f);
                player.sendAbilitiesUpdate();
                player.addVelocity(0, 0.25, 0);
                player.velocityModified = true;
            }
            case EARTH -> digTunnel(player, world, x2 ? 40 : 20);
            case WATER -> placeSphere(player, world, Blocks.WATER, radius);
            case LAVA -> {
                placeSphere(player, world, Blocks.LAVA, radius);
                player.setFireTicks(0);
                player.addStatusEffect(new net.minecraft.entity.effect.StatusEffectInstance(net.minecraft.entity.effect.StatusEffects.FIRE_RESISTANCE, 20 * 60, 0, false, true, true));
            }
        }
    }

    private static BlockPos target(ServerPlayerEntity player, int range) {
        var hit = player.raycast(range, 0.0f, false);
        if (hit instanceof net.minecraft.util.hit.BlockHitResult blockHit && hit.getType() == net.minecraft.util.hit.HitResult.Type.BLOCK) return blockHit.getBlockPos();
        Vec3d p = player.getEyePos().add(player.getRotationVec(1.0f).multiply(Math.min(range, 12)));
        return BlockPos.ofFloored(p);
    }

    private static void placeSphere(ServerPlayerEntity player, ServerWorld world, Block block, int radius) {
        BlockPos center = target(player, 24);
        int r2 = radius * radius;
        // Only replace air/replaceable blocks so the sphere does not erase solid terrain.
        for (int x = -radius; x <= radius; x++) for (int y = -radius; y <= radius; y++) for (int z = -radius; z <= radius; z++) {
            if (x*x + y*y + z*z > r2) continue;
            BlockPos pos = center.add(x, y, z);
            if (world.isInBuildLimit(pos)) {
                BlockState state = world.getBlockState(pos);
                if (state.isAir() || state.isReplaceable()) world.setBlockState(pos, block.getDefaultState(), Block.NOTIFY_ALL);
            }
        }
    }

    private static void digTunnel(ServerPlayerEntity player, ServerWorld world, int length) {
        Vec3d look = player.getRotationVec(1.0f).normalize();
        BlockPos.Mutable pos = new BlockPos.Mutable();
        for (int step = 1; step <= length; step++) {
            Vec3d point = player.getPos().add(look.multiply(step));
            int cx = (int)Math.floor(point.x), cy = (int)Math.floor(point.y), cz = (int)Math.floor(point.z);
            for (int x = -1; x <= 1; x++) for (int y = 0; y <= 2; y++) for (int z = -1; z <= 1; z++) {
                pos.set(cx + x, cy + y, cz + z);
                BlockState state = world.getBlockState(pos);
                if (!state.isAir() && !state.isOf(Blocks.BEDROCK) && state.getHardness(world, pos) >= 0) world.breakBlock(pos, true, player);
            }
        }
    }
}
