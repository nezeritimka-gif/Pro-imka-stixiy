package ru.imka.stihii.client;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandRegistrationCallback;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;
import com.mojang.brigadier.Command;
import static net.fabricmc.fabric.api.client.command.v2.ClientCommandManager.literal;

public class StihiiClient implements ClientModInitializer {
    private static int progress = 0;
    private static int joinTicks = -1;
    private static boolean menuOpened = false;
    public static final Identifier MENU_TEXTURE = Identifier.of("stihii", "textures/gui/menu.png");

    @Override public void onInitializeClient() {
        ClientCommandRegistrationCallback.EVENT.register((dispatcher, registryAccess) -> dispatcher.register(literal("menu").executes(ctx -> {
            MinecraftClient.getInstance().execute(() -> MinecraftClient.getInstance().setScreen(new ElementMenuScreen()));
            return Command.SINGLE_SUCCESS;
        })));
        ClientPlayConnectionEvents.JOIN.register((handler, sender, client) -> { joinTicks = 0; menuOpened = false; progress = 0; });
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            if (joinTicks >= 0 && client.player != null) {
                joinTicks++;
                if (joinTicks > 35 && !menuOpened && client.currentScreen == null) {
                    client.setScreen(new ElementMenuScreen()); menuOpened = true; joinTicks = -1;
                }
            }
        });
        HudRenderCallback.EVENT.register((context, tickDelta) -> renderHud(context, MinecraftClient.getInstance()));
    }

    private static void renderHud(DrawContext context, MinecraftClient client) {
        if (client.player == null || client.options.hudHidden) return;
        int x = 10, y = 10, width = 112, height = 8;
        context.drawText(client.textRenderer, Text.literal("ПРОБУЖДЕНИЕ " + progress + "%"), x, y, 0xFFFFFFFF, true);
        context.fill(x, y + 13, x + width, y + 13 + height, 0xAA20202A);
        context.fill(x + 1, y + 14, x + 1 + (width - 2) * progress / 100, y + 13 + height - 1, 0xFFB66BFF);
    }

    public static void localAbilityUsed() { progress += 20; if (progress >= 100) progress = 0; }

    private static class ElementMenuScreen extends Screen {
        protected ElementMenuScreen() { super(Text.literal("Стихии: Пробуждение магии")); }
        @Override protected void init() {
            int w = 150, h = 24, gap = 7, x = (this.width - w) / 2, y = this.height / 2 - 54;
            addDrawableChild(ButtonWidget.builder(Text.literal("Сфера Земли"), b -> choose("earth")).dimensions(x, y, w, h).build());
            addDrawableChild(ButtonWidget.builder(Text.literal("Сфера Воды"), b -> choose("water")).dimensions(x, y + h + gap, w, h).build());
            addDrawableChild(ButtonWidget.builder(Text.literal("Сфера Лавы"), b -> choose("lava")).dimensions(x, y + (h + gap) * 2, w, h).build());
            addDrawableChild(ButtonWidget.builder(Text.literal("Сфера Воздуха"), b -> choose("air")).dimensions(x, y + (h + gap) * 3, w, h).build());
        }
        private void choose(String element) {
            MinecraftClient client = MinecraftClient.getInstance();
            if (client.player != null && client.getNetworkHandler() != null) client.getNetworkHandler().sendChatCommand("stihii " + element);
            client.setScreen(null);
        }
        @Override public void render(DrawContext context, int mouseX, int mouseY, float delta) {
            renderBackground(context, mouseX, mouseY, delta);
            context.drawCenteredTextWithShadow(textRenderer, title, width / 2, height / 2 - 88, 0xFFFFFFFF);
            super.render(context, mouseX, mouseY, delta);
        }
        @Override public boolean shouldPause() { return false; }
    }
}
