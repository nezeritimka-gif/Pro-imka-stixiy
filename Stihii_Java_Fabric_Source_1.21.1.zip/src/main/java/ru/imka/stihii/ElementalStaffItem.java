package ru.imka.stihii;

import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.util.Hand;
import net.minecraft.util.TypedActionResult;
import net.minecraft.world.World;
import net.minecraft.server.network.ServerPlayerEntity;

public class ElementalStaffItem extends Item {
    private final StihiiMod.Element element;
    public ElementalStaffItem(StihiiMod.Element element, Settings settings) {
        super(settings);
        this.element = element;
    }
    @Override public TypedActionResult<ItemStack> use(World world, PlayerEntity user, Hand hand) {
        ItemStack stack = user.getStackInHand(hand);
        if (world.isClient) {
            ru.imka.stihii.client.StihiiClient.localAbilityUsed();
        } else if (user instanceof ServerPlayerEntity serverPlayer) {
            StihiiMod.activate(serverPlayer, element);
        }
        return TypedActionResult.success(stack, world.isClient);
    }
}
