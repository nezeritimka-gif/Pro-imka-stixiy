@echo off
gradle build
if errorlevel 1 exit /b %errorlevel%
echo Build finished. Check build\libs\
pause
